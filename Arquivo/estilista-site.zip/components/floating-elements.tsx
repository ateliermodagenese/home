"use client"

import { motion } from "framer-motion"
import { Heart, Star, Sparkles, Scissors, Palette } from "lucide-react"

export function FloatingElements() {
  const elements = [
    { icon: Heart, color: "text-rose-400", size: "w-6 h-6" },
    { icon: Star, color: "text-yellow-400", size: "w-5 h-5" },
    { icon: Sparkles, color: "text-purple-400", size: "w-4 h-4" },
    { icon: Scissors, color: "text-pink-400", size: "w-5 h-5" },
    { icon: Palette, color: "text-indigo-400", size: "w-6 h-6" },
  ]

  return (
    <div className="fixed inset-0 pointer-events-none z-10 overflow-hidden">
      {elements.map((Element, index) => (
        <motion.div
          key={index}
          className={`absolute ${Element.color} ${Element.size}`}
          style={{
            left: `${10 + index * 20}%`,
            top: `${20 + index * 15}%`,
          }}
          animate={{
            y: [-20, -40, -20],
            x: [-10, 10, -10],
            rotate: [0, 180, 360],
            opacity: [0.3, 0.8, 0.3],
          }}
          transition={{
            duration: 4 + index,
            repeat: Number.POSITIVE_INFINITY,
            delay: index * 0.5,
            ease: "easeInOut",
          }}
        >
          <Element.icon />
        </motion.div>
      ))}
    </div>
  )
}
